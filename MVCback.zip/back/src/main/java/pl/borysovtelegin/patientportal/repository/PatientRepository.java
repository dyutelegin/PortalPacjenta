package pl.borysovtelegin.patientportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.borysovtelegin.patientportal.entity.Patient;

import java.util.UUID;

public interface PatientRepository extends JpaRepository<Patient, String> {
}
