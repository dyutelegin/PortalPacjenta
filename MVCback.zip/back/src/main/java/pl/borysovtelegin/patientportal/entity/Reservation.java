package pl.borysovtelegin.patientportal.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.UUID;

@Entity
public class Reservation {

    @Id
    private String id = UUID.randomUUID().toString();

    @JsonProperty("visit-date")
    private String visitDate;

    @JoinColumn(name = "id_doctor", nullable = false, referencedColumnName = "id")
    @ManyToOne(cascade = CascadeType.DETACH, targetEntity = Doctor.class)
    private Doctor doctor;

    @JoinColumn(name = "id_patient", referencedColumnName = "id")
    @ManyToOne(cascade = CascadeType.DETACH, targetEntity = Patient.class)
    private Patient patient;

    public String getId() {
        return id;
    }

    public Reservation setId(String id) {
        this.id = id;
        return this;
    }

    public String getVisitDate() {
        return visitDate;
    }

    public Reservation setVisitDate(String visitDate) {
        this.visitDate = visitDate;
        return this;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public Reservation setDoctor(Doctor doctor) {
        this.doctor = doctor;
        return this;
    }

    public Patient getPatient() {
        return patient;
    }

    public Reservation setPatient(Patient patient) {
        this.patient = patient;
        return this;
    }
}
