package pl.borysovtelegin.patientportal.rest.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.borysovtelegin.patientportal.entity.Patient;
import pl.borysovtelegin.patientportal.rest.dto.PatientUpdateDTO;
import pl.borysovtelegin.patientportal.service.PatientService;

import java.util.List;

@RequestMapping("/api/patients")
@RestController
public class PatientController {

    private final PatientService patientService;

    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @GetMapping
    public ResponseEntity<List<Patient>> getPatients() {
        return new ResponseEntity<>(patientService.getPatients(), HttpStatus.OK);
    }

    @GetMapping("/{patient-id}")
    public ResponseEntity<Patient> getPatientById(@PathVariable("patient-id") String id) {
        return new ResponseEntity<>(patientService.getPatientById(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Patient> addPatient(@RequestBody Patient patient) {
        return new ResponseEntity<>(patientService.addPatient(patient), HttpStatus.CREATED);
    }

    @PutMapping("/{patient-id}")
    public ResponseEntity<Patient> updatePatient(@PathVariable("patient-id") String id, @RequestBody PatientUpdateDTO dto) {
        System.out.println(id);
        System.out.println(dto);
        return new ResponseEntity<>(patientService.updatePatient(id, dto), HttpStatus.OK);
    }

    @DeleteMapping("/{patient-id}")
    public ResponseEntity<Patient> deletePatient(@PathVariable("patient-id") String id) {
        return new ResponseEntity<>(patientService.deletePatient(id), HttpStatus.OK);
    }

}
