package pl.borysovtelegin.patientportal.service;

import lombok.val;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import pl.borysovtelegin.patientportal.Utils;
import pl.borysovtelegin.patientportal.entity.Reservation;
import pl.borysovtelegin.patientportal.repository.ReservationRepository;
import pl.borysovtelegin.patientportal.rest.dto.ReservationCreateDTO;
import pl.borysovtelegin.patientportal.rest.dto.ReservationUpdateDTO;
import pl.borysovtelegin.patientportal.rest.mapper.ReservationMapper;

import java.util.List;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final ReservationMapper reservationMapper;

    private final DoctorService doctorService;
    private final PatientService patientService;

    public ReservationService(ReservationRepository reservationRepository, ReservationMapper reservationMapper, DoctorService doctorService, PatientService patientService) {
        this.reservationRepository = reservationRepository;
        this.reservationMapper = reservationMapper;
        this.doctorService = doctorService;
        this.patientService = patientService;
    }

    public List<Reservation> getReservations() {
        return reservationRepository.findAll();
    }

    public Reservation getReservationById(String id) {
        val result = reservationRepository.findById(id);
        if (result.isEmpty())
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Reservation with id \"%s\" not found", id));
        return result.get();
    }

    public Reservation createReservation(ReservationCreateDTO dto) {
        val reservation = new Reservation();
        reservation.setVisitDate(dto.getVisitDate());
        reservation.setDoctor(doctorService.getDoctorById(dto.getDoctorId()));
        val patientId = dto.getPatientId();
        if (patientId != null) reservation.setPatient(patientService.getPatientById(patientId));
        return reservationRepository.save(reservation);
    }

    public Reservation updateReservation(String id, ReservationUpdateDTO dto) {
        val reservation = getReservationById(id);
        reservationMapper.update(reservation, dto);
        return reservationRepository.save(reservation);
    }

    public Reservation deleteReservation(String id) {
        val reservation = getReservationById(id);
        reservationRepository.delete(reservation);
        return reservation;
    }

}
