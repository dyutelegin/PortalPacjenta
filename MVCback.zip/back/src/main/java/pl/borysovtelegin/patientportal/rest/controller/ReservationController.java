package pl.borysovtelegin.patientportal.rest.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.borysovtelegin.patientportal.entity.Reservation;
import pl.borysovtelegin.patientportal.rest.dto.ReservationCreateDTO;
import pl.borysovtelegin.patientportal.rest.dto.ReservationUpdateDTO;
import pl.borysovtelegin.patientportal.service.ReservationService;

import java.util.List;

@RequestMapping("/api/reservations")
@RestController
public class ReservationController {

    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @GetMapping
    public ResponseEntity<List<Reservation>> getReservations() {
        return new ResponseEntity<>(reservationService.getReservations(), HttpStatus.OK);
    }

    @GetMapping("/{reservation-id}")
    public ResponseEntity<Reservation> getReservationById(@PathVariable("reservation-id") String id) {
        return new ResponseEntity<>(reservationService.getReservationById(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Reservation> createReservation(@RequestBody ReservationCreateDTO dto) {
        return new ResponseEntity<>(reservationService.createReservation(dto), HttpStatus.CREATED);
    }
    
    @PutMapping("/{reservation-id}")
    public ResponseEntity<Reservation> updateReservation(@PathVariable("reservation-id") String id, @RequestBody ReservationUpdateDTO dto) {
        return new ResponseEntity<>(reservationService.updateReservation(id, dto), HttpStatus.OK);
    }

    @DeleteMapping("/{reservation-id}")
    public ResponseEntity<Reservation> deleteReservation(@PathVariable("reservation-id") String id) {
        return new ResponseEntity<>(reservationService.deleteReservation(id), HttpStatus.OK);
    }

}
