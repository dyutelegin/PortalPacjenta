package pl.borysovtelegin.patientportal.rest.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.borysovtelegin.patientportal.entity.Doctor;
import pl.borysovtelegin.patientportal.rest.dto.DoctorUpdateDTO;
import pl.borysovtelegin.patientportal.service.DoctorService;

import java.util.List;

@RequestMapping("/api/doctors")
@RestController
public class DoctorController {

    private final DoctorService doctorService;

    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @GetMapping
    public ResponseEntity<List<Doctor>> getDoctors() {
        return new ResponseEntity<>(doctorService.getDoctors(), HttpStatus.OK);
    }

    @GetMapping("/{doctor-id}")
    public ResponseEntity<Doctor> getDoctorById(@PathVariable("doctor-id") String id) {
        return new ResponseEntity<>(doctorService.getDoctorById(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Doctor> addDoctor(@RequestBody Doctor doctor) {
        return new ResponseEntity<>(doctorService.addDoctor(doctor), HttpStatus.CREATED);
    }

    @PutMapping("/{doctor-id}")
    public ResponseEntity<Doctor> updateDoctor(@PathVariable("doctor-id") String id, @RequestBody DoctorUpdateDTO dto) {
        return new ResponseEntity<>(doctorService.updateDoctor(id, dto), HttpStatus.OK);
    }

    @DeleteMapping("/{doctor-id}")
    public ResponseEntity<Doctor> deleteDoctor(@PathVariable("doctor-id") String id) {
        return new ResponseEntity<>(doctorService.deleteDoctor(id), HttpStatus.OK);
    }

}
