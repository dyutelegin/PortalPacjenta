package pl.borysovtelegin.patientportal;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.UUID;

public class Utils {

    public static UUID isUUID(String id) {
        try {
            return UUID.fromString(id);
        } catch (IllegalArgumentException iae) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, String.format("Id \"%s\" id not UUID", id));
        }
    }

}
