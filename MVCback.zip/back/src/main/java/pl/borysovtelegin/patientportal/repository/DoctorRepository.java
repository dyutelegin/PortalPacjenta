package pl.borysovtelegin.patientportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.borysovtelegin.patientportal.entity.Doctor;

import java.util.UUID;

public interface DoctorRepository extends JpaRepository<Doctor, String> {
}
