package pl.borysovtelegin.patientportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
