package pl.borysovtelegin.patientportal.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.UUID;

@Data
@Entity
@Table(name = "reservation")
public class Reservation {

    @Column(name = "id", nullable = false, updatable = false)
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Id
    @Type(type = "uuid-char")
    private UUID id;

    @Column(name = "visit_date", nullable = false)
    @JsonProperty("visit-date")
    private String visitDate;

    @JoinColumn(name = "id_doctor", nullable = false, referencedColumnName = "id")
    @ManyToOne(cascade = CascadeType.DETACH, targetEntity = Doctor.class)
    private Doctor doctor;

    @JoinColumn(name = "id_patient", referencedColumnName = "id")
    @ManyToOne(cascade = CascadeType.DETACH, targetEntity = Patient.class)
    private Patient patient;

}
