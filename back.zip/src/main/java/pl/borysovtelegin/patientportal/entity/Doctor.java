package pl.borysovtelegin.patientportal.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.UUID;

@Data
@Entity
@Table(name = "doctor")
public class Doctor {

    @Column(name = "id", nullable = false, updatable = false)
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Id
    @Type(type = "uuid-char")
    private UUID id;

    @Column(name = "first_name", nullable = false)
    @JsonProperty("first-name")
    private String firstName;

    @Column(name = "last_name", nullable = false)
    @JsonProperty("last-name")
    private String lastName;

    @Column(name = "job_position", nullable = false)
    @JsonProperty("job-position")
    private String jobPosition;

}
