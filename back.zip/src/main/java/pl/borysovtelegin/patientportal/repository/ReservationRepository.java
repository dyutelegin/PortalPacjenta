package pl.borysovtelegin.patientportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.borysovtelegin.patientportal.entity.Reservation;

import java.util.UUID;

public interface ReservationRepository extends JpaRepository<Reservation, UUID> {
}
