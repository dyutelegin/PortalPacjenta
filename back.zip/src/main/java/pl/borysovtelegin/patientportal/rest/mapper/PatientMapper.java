package pl.borysovtelegin.patientportal.rest.mapper;

import lombok.val;
import pl.borysovtelegin.patientportal.entity.Patient;
import pl.borysovtelegin.patientportal.rest.dto.PatientUpdateDTO;

public class PatientMapper {

    public static void update(Patient patient, PatientUpdateDTO dto) {
        val firstName = dto.getFirstName();
        if (firstName != null) patient.setFirstName(firstName);

        val lastName = dto.getLastName();
        if (lastName != null) patient.setLastName(lastName);

        val pesel = dto.getPesel();
        if (pesel != null) patient.setPesel(pesel);

        val address = dto.getAddress();
        if (address != null) patient.setAddress(address);
    }

}
