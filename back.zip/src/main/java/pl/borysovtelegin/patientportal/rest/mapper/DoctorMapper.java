package pl.borysovtelegin.patientportal.rest.mapper;

import lombok.val;
import pl.borysovtelegin.patientportal.entity.Doctor;
import pl.borysovtelegin.patientportal.rest.dto.DoctorUpdateDTO;

public class DoctorMapper {

    public static void update(Doctor doctor, DoctorUpdateDTO dto) {
        val firstName = dto.getFirstName();
        if (firstName != null) doctor.setFirstName(firstName);

        val lastName = dto.getLastName();
        if (lastName != null) doctor.setLastName(lastName);

        val jobPosition = dto.getJobPosition();
        if (jobPosition != null) doctor.setJobPosition(jobPosition);
    }

}
