package pl.borysovtelegin.patientportal.rest.mapper;

import lombok.val;
import org.springframework.stereotype.Component;
import pl.borysovtelegin.patientportal.entity.Reservation;
import pl.borysovtelegin.patientportal.rest.dto.ReservationUpdateDTO;
import pl.borysovtelegin.patientportal.service.DoctorService;
import pl.borysovtelegin.patientportal.service.PatientService;

@Component
public class ReservationMapper {

    private final DoctorService doctorService;
    private final PatientService patientService;

    public ReservationMapper(DoctorService doctorService, PatientService patientService) {
        this.doctorService = doctorService;
        this.patientService = patientService;
    }

    public void update(Reservation reservation, ReservationUpdateDTO dto) {
        val visitDate = dto.getVisitDate();
        if (visitDate != null) reservation.setVisitDate(visitDate);

        val doctorId = dto.getDoctorId();
        if (doctorId != null) reservation.setDoctor(doctorService.getDoctorById(doctorId));

        val patientId = dto.getPatientId();
        if (patientId != null) reservation.setPatient(patientService.getPatientById(patientId));
    }

}
