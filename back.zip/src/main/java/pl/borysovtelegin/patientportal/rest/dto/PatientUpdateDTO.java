package pl.borysovtelegin.patientportal.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PatientUpdateDTO {

    @JsonProperty("fist-name")
    private String firstName;

    @JsonProperty("last-name")
    private String lastName;

    private String pesel;

    private String address;

}
