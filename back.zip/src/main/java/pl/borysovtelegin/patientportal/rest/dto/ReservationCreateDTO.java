package pl.borysovtelegin.patientportal.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ReservationCreateDTO {

    @JsonProperty("visit-date")
    private String visitDate;

    @JsonProperty("doctor-id")
    private String doctorId;

    @JsonProperty("patient-id")
    private String patientId;

}
