package pl.borysovtelegin.patientportal.rest.dto;

public class ReservationUpdateDTO extends ReservationCreateDTO {
}
