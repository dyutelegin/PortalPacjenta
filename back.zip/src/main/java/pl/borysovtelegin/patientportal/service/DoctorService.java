package pl.borysovtelegin.patientportal.service;

import lombok.val;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import pl.borysovtelegin.patientportal.Utils;
import pl.borysovtelegin.patientportal.entity.Doctor;
import pl.borysovtelegin.patientportal.repository.DoctorRepository;
import pl.borysovtelegin.patientportal.rest.dto.DoctorUpdateDTO;
import pl.borysovtelegin.patientportal.rest.mapper.DoctorMapper;

import java.util.List;

@Service
public class DoctorService {

    private final DoctorRepository doctorRepository;

    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    public List<Doctor> getDoctors() {
        return doctorRepository.findAll();
    }

    public Doctor getDoctorById(String id) {
        val uuid = Utils.isUUID(id);
        val result = doctorRepository.findById(uuid);
        if (result.isEmpty())
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Doctor with id \"%s\" not found", id));
        return result.get();
    }

    public Doctor addDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    public Doctor updateDoctor(String id, DoctorUpdateDTO dto) {
        val doctor = getDoctorById(id);
        DoctorMapper.update(doctor, dto);
        return doctorRepository.save(doctor);
    }

    public Doctor deleteDoctor(String id) {
        val doctor = getDoctorById(id);
        doctorRepository.delete(doctor);
        return doctor;
    }

}
