package pl.borysovtelegin.patientportal.service;

import lombok.val;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import pl.borysovtelegin.patientportal.Utils;
import pl.borysovtelegin.patientportal.entity.Patient;
import pl.borysovtelegin.patientportal.repository.PatientRepository;
import pl.borysovtelegin.patientportal.rest.dto.PatientUpdateDTO;
import pl.borysovtelegin.patientportal.rest.mapper.PatientMapper;

import java.util.List;

@Service
public class PatientService {

    private final PatientRepository patientRepository;

    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    public List<Patient> getPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatientById(String id) {
        val uuid = Utils.isUUID(id);
        val result = patientRepository.findById(uuid);
        if (result.isEmpty())
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Patient with id \"%s\" not found", id));
        return result.get();
    }

    public Patient addPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    public Patient updatePatient(String id, PatientUpdateDTO dto) {
        val patient = getPatientById(id);
        PatientMapper.update(patient, dto);
        return patientRepository.save(patient);
    }

    public Patient deletePatient(String id) {
        val patient = getPatientById(id);
        patientRepository.delete(patient);
        return patient;
    }

}
