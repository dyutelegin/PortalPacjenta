import "./App.css"
import {BrowserRouter, NavLink, Route, Routes} from "react-router-dom";
import Reservation from "./components/pages/Reservation";
import Patient from "./components/pages/Patient";
import Doctor from "./components/pages/Doctor";
import AddReservation from "./components/pages/AddReservation";
import AddDoctor from "./components/pages/AddDoctor";
import AddPatient from "./components/pages/AddPatient";

function App() {
    return (
        <BrowserRouter>
            <header>
                <nav>
                    <ul>
                        <li><NavLink to="/">Reservations</NavLink></li>
                        <li><NavLink to="/doctors">Doctors</NavLink></li>
                        <li><NavLink to="/patients">Patients</NavLink></li>
                    </ul>
                </nav>
            </header>
            <Routes>
                <Route path="/" element={<Reservation/>}/>
                <Route path="/add-reservation" element={<AddReservation/>}/>
                <Route path="/patients" element={<Patient/>}/>
                <Route path="/patients/add" element={<AddPatient/>}/>
                <Route path="/doctors" element={<Doctor/>}/>
                <Route path="/doctors/add" element={<AddDoctor/>}/>
            </Routes>
        </BrowserRouter>
    );
}

export default App;
