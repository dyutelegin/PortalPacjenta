import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";

const Reservation = () => {
    const [reservations, setreservations] = useState([])
    const navigate = useNavigate();

    useEffect(() => {
        const fetchPatients = async () => {
            const response = await fetch("http://localhost:8080/reservations");
            if (response.ok) setreservations(await response.json());
        }
        fetchPatients().then();
    }, []);

    const deleteHandler = async (id) => {
        await fetch(`http://localhost:8080/reservations/${id}`, {method: "DELETE"});
        setreservations((prevReservation) => prevReservation.filter(({id: reservationId}) => reservationId !== id));
    }

    const addReservationHandler = () => navigate("/add-reservation");

    let reservationsComponent
    if (!reservations.length) {
        reservationsComponent = <p>No Reservations</p>;
    } else {
        reservationsComponent = <table>
            <tr>
                <th>Doctor</th>
                <th>Patient</th>
                <th>Visit Date</th>
                <th>Action</th>
            </tr>
            {reservations.map((reservation) => <tr>
                <td>{`${reservation.doctor["first-name"]} ${reservation.doctor["last-name"]} (${reservation.doctor["job-position"]})`}</td>
                <td>{`${reservation.patient["first-name"]} ${reservation.patient["last-name"]}`}</td>
                <td>{reservation["visit-date"]}</td>
                <td>
                    <button className="button button3" onClick={deleteHandler.bind(null, reservation.id)}
                            type="button">Delete
                        this item
                    </button>
                </td>
            </tr>)}
        </table>
    }

    return <>
        {reservationsComponent}
        <button className="button button1" onClick={addReservationHandler} type="button">Add new Reservation
        </button>
    </>
}

export default Reservation;
