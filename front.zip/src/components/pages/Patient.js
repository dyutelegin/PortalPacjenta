import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";

const Patient = () => {
    const navigate = useNavigate();

    const [patients, setPatients] = useState([])

    useEffect(() => {
        const fetchPatients = async () => {
            const response = await fetch("http://localhost:8080/patients");
            if (response.ok) setPatients(await response.json());
        }
        fetchPatients().then();
    }, []);

    const deleteHandler = async (id) => {
        await fetch(`http://localhost:8080/patients/${id}`, {method: "DELETE"});
        setPatients((prevPatients) => prevPatients.filter(({id: patientId}) => patientId !== id));
    }

    const addPatientHandler = () => navigate("add");

    let patientsComponent
    if (!patients.length) {
        patientsComponent = <p>No Patients</p>;
    } else {
        patientsComponent = <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>PESEL</th>
                <th>Address</th>
                <th>Action</th>
            </tr>
            {patients.map((patient) => <tr>
                <td>{patient.id}</td>
                <td>{patient["first-name"]}</td>
                <td>{patient["last-name"]}</td>
                <td>{patient.pesel}</td>
                <td>{patient.address}</td>
                <td>
                    <button className="button button3" onClick={deleteHandler.bind(null, patient.id)}
                            type="button">Delete
                        this item
                    </button>
                </td>
            </tr>)}
        </table>
    }

    return <>
        {patientsComponent}
        <button className="button button1" onClick={addPatientHandler} type="button">Add new Patient
        </button>
    </>
}

export default Patient;
