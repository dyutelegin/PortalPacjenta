import {useNavigate} from "react-router-dom";
import {useRef} from "react";

const AddDoctor = () => {
    const navigate = useNavigate();

    const firstNameRef = useRef();
    const lastNameRef = useRef();
    const jobPosition = useRef();

    const submitHandler = async (event) => {
        event.preventDefault();
        const firstNameValue = firstNameRef.current.value.trim();
        const lastNameValue = lastNameRef.current.value.trim();
        const jobPositionValue = jobPosition.current.value.trim();

        const requestBody = {
            "first-name": firstNameValue,
            "last-name": lastNameValue,
            "job-position": jobPositionValue
        }

        await fetch("http://localhost:8080/doctors", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(requestBody)
        });

        navigate("/doctors");
    }

    return <form onSubmit={submitHandler}>
        <label htmlFor="first-name">First Name</label>
        <input id="first-name" type="text" name="first-name" ref={firstNameRef}/>
        <label htmlFor="last-name">Last Name</label>
        <input id="last-name" type="text" name="last-name" ref={lastNameRef}/>
        <label htmlFor="job-position">Job Position</label>
        <input id="job-position" type="text" name="job" ref={jobPosition}/>
        <input type="submit" value="Add new Doctor"/>
    </form>;
}

export default AddDoctor;
