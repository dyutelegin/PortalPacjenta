import {useNavigate} from "react-router-dom";
import {useEffect, useState, useRef} from "react";
import moment from "moment/moment";

const AddReservation = () => {
    const [doctors, setDoctors] = useState([]);
    const [patients, setPatients] = useState([]);

    const navigate = useNavigate();

    const doctorRef = useRef();
    const patientRef = useRef();
    const visitDateRef = useRef();
    const timeRef = useRef();

    useEffect(() => {
        const fetchDoctors = async () => {
            const response = await fetch("http://localhost:8080/doctors");
            if (response.ok) setDoctors(await response.json());
        }
        fetchDoctors().then();
    }, [])

    useEffect(() => {
        const fetchPatients = async () => {
            const response = await fetch("http://localhost:8080/patients");
            if (response.ok) setPatients(await response.json());
        }
        fetchPatients().then();
    }, []);

    const submitHandler = async (event) => {
        event.preventDefault();

        const doctorValue = doctorRef.current.value;
        const patientValue = patientRef.current.value;
        const visitDateValue = visitDateRef.current.value;
        const timeValue = timeRef.current.value;

        const requestBody = {
            "visit-date": `${visitDateValue} ${timeValue}`,
            "doctor-id": doctorValue,
            "patient-id": patientValue
        }

        await fetch("http://localhost:8080/reservations", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(requestBody)
        });

        navigate("/");
    }

    return <form onSubmit={submitHandler}>
        <label htmlFor="doctor">Doctor</label>
        <select id="doctor" name="doctor" ref={doctorRef}>
            {doctors.map(doctor => (
                <option
                    value={doctor.id}>{`${doctor["first-name"]} ${doctor["last-name"]} (${doctor["job-position"]})`}</option>
            ))}
        </select>
        <label htmlFor="patient">Patient</label>
        <select id="patient" name="patient" ref={patientRef}>
            {patients.map(patient => (
                <option
                    value={patient.id}>{`${patient["first-name"]} ${patient["last-name"]}`}</option>
            ))}
        </select>
        <label htmlFor="date">Visit Date</label>
        <input id="date" type="date" min={moment().format("YYYY-MM-DD")} ref={visitDateRef}/>
        <label htmlFor="time">Time</label>
        <input id="time" type="time" ref={timeRef}/>
        <input type="submit" value="Add new Reservation"/>
    </form>;
}

export default AddReservation;
