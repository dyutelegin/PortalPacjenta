import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";

const Doctor = () => {
    const [doctors, setDoctors] = useState([])
    const navigate = useNavigate();

    useEffect(() => {
        const fetchDoctors = async () => {
            const response = await fetch("http://localhost:8080/doctors");
            if (response.ok) setDoctors(await response.json());
        }
        fetchDoctors().then();
    }, []);

    const deleteHandler = async (id) => {
        await fetch(`http://localhost:8080/doctors/${id}`, {method: "DELETE"});
        setDoctors((prevDoctors) => prevDoctors.filter(({id: doctorId}) => doctorId !== id));
    }

    const addDoctorHandler = () => navigate("add");

    let doctorsComponent
    if (!doctors.length) {
        doctorsComponent = <p>No Doctors</p>;
    } else {
        doctorsComponent = <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Job Position</th>
                <th>Action</th>
            </tr>
            {doctors.map((doctor) => <tr>
                <td>{doctor.id}</td>
                <td>{doctor["first-name"]}</td>
                <td>{doctor["last-name"]}</td>
                <td>{doctor["job-position"]}</td>
                <td>
                    <button className="button button3" onClick={deleteHandler.bind(null, doctor.id)}
                            type="button">Delete
                        this item
                    </button>
                </td>
            </tr>)}
        </table>
    }

    return <>
        {doctorsComponent}
        <button className="button button1" onClick={addDoctorHandler} type="button">Add new Doctor
        </button>
    </>
}

export default Doctor;
