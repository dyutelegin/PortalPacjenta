import {useNavigate} from "react-router-dom";
import {useRef} from "react";

const AddPatient = () => {
    const navigate = useNavigate();

    const firstNameRef = useRef();
    const lastNameRef = useRef();
    const peselRef = useRef();
    const addressRef = useRef();

    const submitHandler = async (event) => {
        event.preventDefault();
        const firstNameValue = firstNameRef.current.value.trim();
        const lastNameValue = lastNameRef.current.value.trim();
        const peselValue = peselRef.current.value.trim();
        const addressValue = addressRef.current.value.trim();

        const requestBody = {
            "first-name": firstNameValue,
            "last-name": lastNameValue,
            "pesel": peselValue,
            "address": addressValue
        }

        await fetch("http://localhost:8080/patients", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(requestBody)
        });

        navigate("/patients");
    }

    return <form onSubmit={submitHandler}>
        <label htmlFor="first-name">First Name</label>
        <input id="first-name" type="text" name="first-name" ref={firstNameRef}/>
        <label htmlFor="last-name">Last Name</label>
        <input id="last-name" type="text" name="last-name" ref={lastNameRef}/>
        <label htmlFor="pesel">PESEL</label>
        <input id="pesel" type="text" name="pesel" ref={peselRef}/>
        <label htmlFor="address">Address</label>
        <input id="address" type="text" name="address" ref={addressRef}/>
        <input type="submit" value="Add new Patient"/>
    </form>;
}

export default AddPatient;
